<div style="margin-top: 85px">
    <?php get_header(); ?>
    <h1>
        <?php the_title(); ?>
    </h1>
    <div class="content">
        <?php the_content(); ?>
    </div>
</div>
<?php get_footer(); ?>