</div>
</body>
<?php require_once('partials/footer.php'); ?>

</html>